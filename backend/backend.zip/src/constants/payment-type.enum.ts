export const PAYMENT_TYPE = {
  cod: "COD",
  upi: "upi",
  card: "card",
  online: "online"
};

export const PAYMENT_STATUS = {
  pending: "pending",
  paid: "paid",
  cancelled: "cancelled",
};
