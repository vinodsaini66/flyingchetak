export const TRANSACTION_TYPES = {
  toCustomer: "to customer",
  toAdmin: "to admin",
};
