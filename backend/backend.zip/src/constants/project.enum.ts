export const CONASTANT = {
    DB_URL: "mongodb+srv://yashpal:Yashpal1990@coachingappcluster.rkruzgs.mongodb.net/flyingChetak?retryWrites=true&w=majority",
    JWT_SECRET: "wingsFly",
    JWT_TIMEOUT_DURATION:"6400000",
    REDIRECTION_URL:"http://35.202.132.15/api/app/wallet/add/balance-via-third-party",
    BASE_URL:"http://35.202.132.15"
  };