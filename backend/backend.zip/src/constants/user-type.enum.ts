export const USER_TYPE = {
  admin: "Admin",
  customer: "Customer",
};
