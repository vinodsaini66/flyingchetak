export const TYPES = {
  product: "Product",
  service: "Service",
};
