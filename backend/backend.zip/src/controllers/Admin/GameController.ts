const express = require("express");

const cookieParser = require("cookie-parser");

const app = express();

export class GameController {}
